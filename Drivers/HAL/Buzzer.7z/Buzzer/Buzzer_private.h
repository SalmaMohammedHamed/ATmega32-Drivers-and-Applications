/*
 * Buzzer_private.h
 *
 *  Created on: Sep 10, 2023
 *      Author: salma
 */

#ifndef HAL_BUZZER_BUZZER_PRIVATE_H_
#define HAL_BUZZER_BUZZER_PRIVATE_H_

#endif /* HAL_BUZZER_BUZZER_PRIVATE_H_ */
